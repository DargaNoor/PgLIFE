package com.example.rest_service;

import org.bouncycastle.jce.provider.BouncyCastleProvider;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import java.security.KeyFactory;
import java.security.PublicKey;
import java.security.Security;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.Base64;

public class App {

  static {
      // Add BouncyCastle as a security provider
      Security.addProvider(new BouncyCastleProvider());
  }

  public static void main(String[] args) throws Exception {
      // Generate a symmetric key (AES key in this case)
      KeyGenerator keyGen = KeyGenerator.getInstance("AES");
      keyGen.init(256);
      SecretKey symmetricKey = keyGen.generateKey();

      // Generated certificate string
      String certificateString = "-----BEGIN CERTIFICATE-----\r\n"
      		+ "MIICtDCCAZygAwIBAgIGAY+VvpDSMA0GCSqGSIb3DQEBCwUAMBsxGTAXBgNVBAMM\r\n"
      		+ "EFRlc3QgQ2VydGlmaWNhdGUwHhcNMjQwNTIwMTEyNDA1WhcNMjUwNTIwMTEyNDA1\r\n"
      		+ "WjAbMRkwFwYDVQQDDBBUZXN0IENlcnRpZmljYXRlMIIBIjANBgkqhkiG9w0BAQEF\r\n"
      		+ "AAOCAQ8AMIIBCgKCAQEA0xG1w6kUTmlN6sk9poEOjeBbfALT2mIfC/rsDy8a+M1T\r\n"
      		+ "RfMv0DFay6ycDHPhcOIQn25Ub+MOkcGzpOD1V7X2/VDwaDlSiqfDBS/1pgz9m5Z2\r\n"
      		+ "fFlLjPI0B73RkfYQrM99ejPQobJKsiwATQhcx0yFJKeimT6Nk9wYo+VG+d+/Sed9\r\n"
      		+ "N4cMrD+S0/CvRaXx7lkdeCmLtWLIQwEKmagK/qk9A/n+fFypdXMLgXuU0cnz6PRb\r\n"
      		+ "8GpByNX+EqZ3XBgJmHu4OJuGyEGYhOII8Q16BQZczR9CwV0gZHBjycPWAjcxFYau\r\n"
      		+ "CsZK59SNtXK09q7p8wud3f4NJC+7I6SGTF6LNKEmHQIDAQABMA0GCSqGSIb3DQEB\r\n"
      		+ "CwUAA4IBAQBnFU091UabnP/wu+8w/2pNpVWvgqhhohFQpBZKhz0yATxYNfz3U1kp\r\n"
      		+ "nQto8+LvFnxsxLCE0VZKeZmuk3y7OD0SxksWW6Xq/YwRjcLdbPnk3IWLuf62lPTo\r\n"
      		+ "O25rYWmKZBiNIgiCmVNQKs0s71ZC74umP3l7GX9F3QTwkiQxpUzhRmf/HV9fj1k2\r\n"
      		+ "T/v0JtB56e7fiffLZ4yTE6pWEabQfBLHAsXKnBDIZtTGK04FKrkmKmQqhMiNOvTR\r\n"
      		+ "5mOdeAShP7P3fMEwxQxsVeJHvGzgQ+7njBDjrWxNaVA7t6IEkiPezdKw6RKv65FR\r\n"
      		+ "Nm/udaOWAi2+C3etvXEoQswBk4vRWeY/\r\n"
      		+ "-----END CERTIFICATE-----";

      // Extract the public key from the certificate
      PublicKey publicKey = getPublicKeyFromCertificate(certificateString);
      System.out.println(publicKey);
      // Encrypt the symmetric key using RSA-OAEP with MGF1
      byte[] encryptedKey = encryptKeyWithRSAOAEP(symmetricKey.getEncoded(), publicKey);

      // Encode the encrypted key as Base64 for inclusion in an XML element
      String cipherValue = Base64.getEncoder().encodeToString(encryptedKey);
      System.out.println("EncryptedKey CipherValue: " + cipherValue);
  }

  public static PublicKey getPublicKeyFromCertificate(String certString) throws Exception {
      certString = certString.replace("-----BEGIN CERTIFICATE-----", "")
                             .replace("-----END CERTIFICATE-----", "")
                             .replaceAll("\\s", "");

      byte[] certBytes = Base64.getDecoder().decode(certString);
      CertificateFactory certificateFactory = CertificateFactory.getInstance("X.509");
      X509Certificate certificate = (X509Certificate) certificateFactory.generateCertificate(new java.io.ByteArrayInputStream(certBytes));
      return certificate.getPublicKey();
  }

  public static byte[] encryptKeyWithRSAOAEP(byte[] key, PublicKey publicKey) throws Exception {
      Cipher cipher = Cipher.getInstance("RSA/ECB/OAEPWithSHA-256AndMGF1Padding", "BC");
      cipher.init(Cipher.ENCRYPT_MODE, publicKey);
      return cipher.doFinal(key);
  }
}
