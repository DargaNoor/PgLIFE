package com.example.rest_service;

import java.security.*;
import java.util.Collections;

import javax.xml.crypto.dsig.*;
import javax.xml.crypto.dsig.dom.DOMSignContext;
import javax.xml.crypto.dsig.keyinfo.*;
import javax.xml.crypto.dsig.spec.*;
import javax.xml.parsers.*;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.*;

public class App {

  public static void main(String[] args) throws Exception {
      // Step 1: Generate a random reference ID
      String referenceID = generateReferenceID();
      System.out.println("Reference ID: " + referenceID);

      // Step 2: Create a SOAP message (for simplicity, let's consider a simple XML document)
      DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
      DocumentBuilder db = dbf.newDocumentBuilder();
      Document doc = db.newDocument();
      Element rootElement = doc.createElement("SOAP-ENV:Envelope");
      doc.appendChild(rootElement);
      Element bodyElement = doc.createElement("SOAP-ENV:Body");
      bodyElement.setTextContent("This is the content of the SOAP Body.");
      rootElement.appendChild(bodyElement);

      // Step 3: Create a digital signature
      // Create a DOM XMLSignatureFactory
      XMLSignatureFactory signatureFactory = XMLSignatureFactory.getInstance("DOM");

      // Create a Reference to the enveloped document (in this case, we are signing the whole document)
      Reference ref = signatureFactory.newReference("", signatureFactory.newDigestMethod(DigestMethod.SHA1, null));

      // Create the SignedInfo
      SignedInfo signedInfo = signatureFactory.newSignedInfo(signatureFactory.newCanonicalizationMethod(CanonicalizationMethod.INCLUSIVE,
              (C14NMethodParameterSpec) null), signatureFactory.newSignatureMethod(SignatureMethod.RSA_SHA1, null), 
              Collections.singletonList(ref));
      KeyPairGenerator kpg = KeyPairGenerator.getInstance("RSA");
      kpg.initialize(2048);
      KeyPair kp = kpg.generateKeyPair();

      KeyInfoFactory kif = signatureFactory.getKeyInfoFactory();
      KeyValue kv = kif.newKeyValue(kp.getPublic());

      KeyInfo ki = kif.newKeyInfo(Collections.singletonList(kv));

      XMLSignature signature = signatureFactory.newXMLSignature(signedInfo, ki);
      DOMSignContext dsc = new DOMSignContext(kp.getPrivate(), doc);
      signature.sign(dsc);

      // Step 4: Print the signed SOAP message
      System.out.println("Signed SOAP message:\n" + convertDocumentToString(doc));
  }

  private static String generateReferenceID() {
      return "id-" + java.util.UUID.randomUUID().toString();
  }

  private static String convertDocumentToString(Document doc) throws Exception {
      DOMSource domSource = new DOMSource(doc);
      StringWriter writer = new StringWriter();
      StreamResult result = new StreamResult(writer);
      TransformerFactory tf = TransformerFactory.newInstance();
      Transformer transformer = tf.newTransformer();
      transformer.transform(domSource, result);
      return writer.toString();
  }
}
