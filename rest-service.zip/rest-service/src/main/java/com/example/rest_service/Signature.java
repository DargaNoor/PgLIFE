package com.example.rest_service;

import java.io.FileInputStream;
import java.security.KeyStore;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.security.KeyFactory;
import java.security.MessageDigest;
import java.security.PrivateKey;
import java.security.Signature;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Base64;

public class App {
  public static void main(String[] args) throws Exception {
      // Your XML data
      String xmlData = "<SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ds=\"http://www.w3.org/2000/09/xmldsig#\" xmlns:wsse=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd\" xmlns:wsu=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\">\n" +
              "    <SOAP-ENV:Header>\n" +
              "        <wsse:Security mustUnderstand=\"1\">\n" +
              "            <wsse:UsernameToken>\n" +
              "                <wsse:Username>B000200206</wsse:Username>\n" +
              "            </wsse:UsernameToken>\n" +
              "            <wsu:Timestamp>\n" +
              "                <wsu:Created>30</wsu:Created>\n" +
              "                <wsu:Expires>30</wsu:Expires>\n" +
              "            </wsu:Timestamp>\n" +
              "            <ds:Signature>\n" +
              "                <ds:SignedInfo>\n" +
              "                    <ds:CanonicalizationMethod Algorithm=\"http://www.w3.org/TR/2001/REC-xml-c14n-20010315\"/>\n" +
              "                    <ds:SignatureMethod Algorithm=\"http://www.w3.org/2000/09/xmldsig#rsa-sha1\"/>\n" +
              "                </ds:SignedInfo>\n" +
              "            </ds:Signature>\n" +
              "        </wsse:Security>\n" +
              "    </SOAP-ENV:Header>\n" +
              "    <SOAP-ENV:Body/>\n" +
              "</SOAP-ENV:Envelope>";

      // Load certificate
      String certString = "-----BEGIN CERTIFICATE-----\n" +
              "MIICtDCCAZygAwIBAgIGAY+VvpDSMA0GCSqGSIb3DQEBCwUAMBsxGTAXBgNVBAMM\n" +
              "EFRlc3QgQ2VydGlmaWNhdGUwHhcNMjQwNTIwMTEyNDA1WhcNMjUwNTIwMTEyNDA1\n" +
              "WjAbMRkwFwYDVQQDDBBUZXN0IENlcnRpZmljYXRlMIIBIjANBgkqhkiG9w0BAQEF\n" +
              "AAOCAQ8AMIIBCgKCAQEA0xG1w6kUTmlN6sk9poEOjeBbfALT2mIfC/rsDy8a+M1T\n" +
              "RfMv0DFay6ycDHPhcOIQn25Ub+MOkcGzpOD1V7X2/VDwaDlSiqfDBS/1pgz9m5Z2\n" +
              "fFlLjPI0B73RkfYQrM99ejPQobJKsiwATQhcx0yFJKeimT6Nk9wYo+VG+d+/Sed9\n" +
              "N4cMrD+S0/CvRaXx7lkdeCmLtWLIQwEKmagK/qk9A/n+fFypdXMLgXuU0cnz6PRb\n" +
              "8GpByNX+EqZ3XBgJmHu4OJuGyEGYhOII8Q16BQZczR9CwV0gZHBjycPWAjcxFYau\n" +
              "CsZK59SNtXK09q7p8wud3f4NJC+7I6SGTF6LNKEmHQIDAQABMA0GCSqGSIb3DQEB\n" +
              "CwUAA4IBAQBnFU091UabnP/wu+8w/2pNpVWvgqhhohFQpBZKhz0yATxYNfz3U1kp\n" +
              "nQto8+LvFnxsxLCE0VZKeZmuk3y7OD0SxksWW6Xq/YwRjcLdbPnk3IWLuf62lPTo\n" +
              "O25rYWmKZBiNIgiCmVNQKs0s71ZC74umP3l7GX9F3QTwkiQxpUzhRmf/HV9fj1k2\n" +
              "T/v0JtB56e7fiffLZ4yTE6pWEabQfBLHAsXKnBDIZtTGK04FKrkmKmQqhMiNOvTR\n" +
              "5mOdeAShP7P3fMEwxQxsVeJHvGzgQ+7njBDjrWxNaVA7t6IEkiPezdKw6RKv65FR\n" +
              "Nm/udaOWAi2+C3etvXEoQswBk4vRWeY/\n" +
              "-----END CERTIFICATE-----";

      // Convert certificate string to X509Certificate
      CertificateFactory cf = CertificateFactory.getInstance("X.509");
      InputStream certInputStream = new ByteArrayInputStream(certString.getBytes());
      X509Certificate cert = (X509Certificate) cf.generateCertificate(certInputStream);

      // Compute SHA-1 hash of canonicalized XML
      MessageDigest digest = MessageDigest.getInstance("SHA-1");
      byte[] xmlBytes = xmlData.getBytes("UTF-8");
      byte[] hashBytes = digest.digest(xmlBytes);

      // Sign the hash
//      PrivateKey privateKey = getPrivateKeyFromCert(cert);
 
    
    KeyStore keystore = KeyStore.getInstance("JKS"); // Or "PKCS12" depending on the type of keystore
    char[] keystorePassword = "keystorePassword".toCharArray();
    String keystorePath = "src/main/resources/keystore.jks";
    keystore.load(new FileInputStream(keystorePath), keystorePassword);

    // Get the private key using the alias and password
    String alias = "keyAlias";
    char[] keyPassword = "keyPassword".toCharArray();
    PrivateKey privateKey = (PrivateKey) keystore.getKey(alias, keyPassword);
    
    
      Signature signature = Signature.getInstance("SHA1withRSA");
      signature.initSign(privateKey);
      signature.update(hashBytes);
      byte[] signedBytes = signature.sign();

      // Print the Base64 encoded signature
      System.out.println("SHA-1 Signature: " + Base64.getEncoder().encodeToString(signedBytes));
  }
//
//  private static PrivateKey getPrivateKeyFromCert(X509Certificate cert) throws Exception {
//      byte[] privateKeyBytes = cert.getPublicKey().getEncoded();
//      PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(privateKeyBytes);
//      KeyFactory keyFactory = KeyFactory.getInstance("RSA");
//      return keyFactory.generatePrivate(keySpec);
//  }
}