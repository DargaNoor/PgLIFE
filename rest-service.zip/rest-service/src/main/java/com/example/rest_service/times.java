
package com.example.rest_service;
import org.bouncycastle.jce.provider.BouncyCastleProvider;

import javax.xml.bind.DatatypeConverter;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.StringWriter;
import java.security.*;
import java.util.Base64;
import java.util.Date;
import javax.crypto.Cipher;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class App {

   static {
       Security.addProvider(new BouncyCastleProvider());
   }

   public static void main(String[] args) throws Exception {
       // Generate RSA key pair
       KeyPairGenerator keyPairGen = KeyPairGenerator.getInstance("RSA");
       keyPairGen.initialize(2048);
       KeyPair keyPair = keyPairGen.generateKeyPair();
       PublicKey publicKey = keyPair.getPublic();
       PrivateKey privateKey = keyPair.getPrivate();

       // Generate timestamp
//        String timestamp = generateTimestamp();
       String timestamp = "2024-04-24T15:49:30.336Z";
       System.out.println("Timestamp: " + timestamp);

       // Compute SHA1 digest
       byte[] digest = computeDigest(timestamp);
       System.out.println("Digest (Base64): " + Base64.getEncoder().encodeToString(digest));

       // Encrypt timestamp
       byte[] encryptedTimestamp = encryptTimestamp(timestamp, publicKey);
       System.out.println("Encrypted Timestamp (Base64): " + Base64.getEncoder().encodeToString(encryptedTimestamp));

       // Sign the digest using RSA-SHA1
       byte[] signature = signDigest(digest, privateKey);
       System.out.println("Signature (Base64): " + Base64.getEncoder().encodeToString(signature));

       // Create XML structure
       String xml = createXMLStructure(timestamp, digest, encryptedTimestamp, signature);
       System.out.println("XML Structure: \n" + xml);
   }

   private static String generateTimestamp() {
       // Generate a simple timestamp
       return Long.toString(new Date().getTime());
   }

   private static byte[] computeDigest(String data) throws Exception {
       MessageDigest digest = MessageDigest.getInstance("SHA-1");
       return digest.digest(data.getBytes("UTF-8"));
   }

   private static byte[] encryptTimestamp(String timestamp, PublicKey publicKey) throws Exception {
       Cipher cipher = Cipher.getInstance("RSA/ECB/OAEPPadding", "BC");
       cipher.init(Cipher.ENCRYPT_MODE, publicKey);
       return cipher.doFinal(timestamp.getBytes("UTF-8"));
   }

   private static byte[] signDigest(byte[] digest, PrivateKey privateKey) throws Exception {
       Signature signature = Signature.getInstance("SHA1withRSA");
       signature.initSign(privateKey);
       signature.update(digest);
       return signature.sign();
   }

   private static String createXMLStructure(String timestamp, byte[] digest, byte[] encryptedTimestamp, byte[] signature) throws Exception {
       DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
       DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
       Document doc = docBuilder.newDocument();

       // Create Signature element
       Element signatureElement = doc.createElement("Signature");
       doc.appendChild(signatureElement);

       // Create SignatureMethod element
       Element signatureMethod = doc.createElement("SignatureMethod");
       signatureMethod.setAttribute("Algorithm", "http://www.w3.org/2000/09/xmldsig#rsa-sha1");
       signatureElement.appendChild(signatureMethod);

       // Create Reference element
       Element reference = doc.createElement("Reference");
       reference.setAttribute("URI", "#TS");
       signatureElement.appendChild(reference);

       // Create DigestMethod element
       Element digestMethod = doc.createElement("DigestMethod");
       digestMethod.setAttribute("Algorithm", "http://www.w3.org/2000/09/xmldsig#sha1");
       reference.appendChild(digestMethod);

       // Create DigestValue element
       Element digestValue = doc.createElement("DigestValue");
       digestValue.appendChild(doc.createTextNode(Base64.getEncoder().encodeToString(digest)));
       reference.appendChild(digestValue);

       // Create EncryptedTimestamp element
       Element encryptedTimestampElement = doc.createElement("EncryptedTimestamp");
       encryptedTimestampElement.setAttribute("Algorithm", "http://www.w3.org/2001/04/xmlenc#rsa-oaep-mgf1p");
       encryptedTimestampElement.appendChild(doc.createTextNode(Base64.getEncoder().encodeToString(encryptedTimestamp)));
       signatureElement.appendChild(encryptedTimestampElement);

       // Create SignatureValue element
       Element signatureValue = doc.createElement("SignatureValue");
       signatureValue.appendChild(doc.createTextNode(Base64.getEncoder().encodeToString(signature)));
       signatureElement.appendChild(signatureValue);

       // Transform document to string
       TransformerFactory transformerFactory = TransformerFactory.newInstance();
       Transformer transformer = transformerFactory.newTransformer();
       DOMSource source = new DOMSource(doc);
       StringWriter writer = new StringWriter();
       StreamResult result = new StreamResult(writer);
       transformer.transform(source, result);

       return writer.toString();
   }
}