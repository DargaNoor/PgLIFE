package com.example.rest_service;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.cert.Certificate;
import java.util.Base64;
import java.util.Enumeration;
import java.util.Properties;
import java.security.SecureRandom;

public class App {
    public static void main(String[] args) throws Exception {
        // Path to your keystore and its password
        String keystorePath = "src/main/resources/keystore.jks";
        String keystorePassword = "keystorePassword";
        String keyAlias = "keyAlias";
        String keyPassword = "keyPassword";
        
        // Load the keystore
        KeyStore keystore = KeyStore.getInstance("JKS");
        try (FileInputStream keystoreInput = new FileInputStream(keystorePath)) {
            keystore.load(keystoreInput, keystorePassword.toCharArray());
        }

        // Retrieve the certificate and private key
        Certificate cert = keystore.getCertificate(keyAlias);
        PublicKey publicKey = cert.getPublicKey();
        PrivateKey privateKey = (PrivateKey) keystore.getKey(keyAlias, keyPassword.toCharArray());

        // Your XML data
//        String xmlData = "<SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ds=\"http://www.w3.org/2000/09/xmldsig#\" xmlns:wsse=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd\" xmlns:wsu=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\">\r\n"
//        		+ "	<SOAP-ENV:Header>\r\n"
//        		+ "	      <wsse:Security mustUnderstand=\"1\">\r\n"
//        		+ "		<wsse:UsernameToken>\r\n"
//        		+ "			<wsse:Username>B000200206</wsse:Username>\r\n"
//        		+ "		</wsse:UsernameToken>\r\n"
//        		+ "        	<wsu:Timestamp>\r\n"
//        		+ "        		<wsu:Created>30</wsu:Created>\r\n"
//        		+ "        		<wsu:Expires>30</wsu:Expires>\r\n"
//        		+ "		</wsu:Timestamp>\r\n"
//        		+ "        	<ds:Signature>\r\n"
//        		+ "          		<ds:SignedInfo>\r\n"
//        		+ "             			<ds:CanonicalizationMethod Algorithm=\"http://www.w3.org/TR/2001/REC-xml-c14n-20010315\"/>\r\n"
//        		+ "             				<ds:SignatureMethod Algorithm=\"http://www.w3.org/2000/09/xmldsig#rsa-sha1\"/>\r\n"
//        		+ "          		</ds:SignedInfo>\r\n"
//        		+ "        	</ds:Signature>\r\n"
//        		+ "  	     </wsse:Security>\r\n"
//        		+ "  	</SOAP-ENV:Header>\r\n"
//        		+ "  	<SOAP-ENV:Body/>\r\n"
//        		+ "</SOAP-ENV:Envelope>";
        String xmlData="<SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ds=\"http://www.w3.org/2000/09/xmldsig#\" xmlns:wsse=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd\" xmlns:wsu=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\"><SOAP-ENV:Header><wsse:Security mustUnderstand=\"1\"><wsse:UsernameToken><wsse:Username>B000200206</wsse:Username></wsse:UsernameToken><wsu:Timestamp><wsu:Created>30</wsu:Created><wsu:Expires>30</wsu:Expires></wsu:Timestamp><ds:Signature><ds:SignedInfo><ds:CanonicalizationMethod Algorithm=\"http://www.w3.org/TR/2001/REC-xml-c14n-20010315\"/><ds:SignatureMethod Algorithm=\"http://www.w3.org/2000/09/xmldsig#rsa-sha1\"/></ds:SignedInfo></ds:Signature></wsse:Security></SOAP-ENV:Header><SOAP-ENV:Body/></SOAP-ENV:Envelope>";

        // Generate AES key and IV
        KeyGenerator keyGen = KeyGenerator.getInstance("AES");
        keyGen.init(128);
        SecretKey aesKey = keyGen.generateKey();
        byte[] iv = new byte[16]; // AES block size is 16 bytes
        SecureRandom random = new SecureRandom();
        random.nextBytes(iv);
        IvParameterSpec ivSpec = new IvParameterSpec(iv);

        // Encrypt XML data using AES
        Cipher aesCipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        aesCipher.init(Cipher.ENCRYPT_MODE, aesKey, ivSpec);
        byte[] encryptedXmlBytes = aesCipher.doFinal(xmlData.getBytes("UTF-8"));

        // Encrypt AES key using RSA (public key from the certificate)
        Cipher rsaCipher = Cipher.getInstance("RSA/ECB/OAEPWithSHA-1AndMGF1Padding");
        rsaCipher.init(Cipher.WRAP_MODE, publicKey);
        byte[] encryptedAesKeyBytes = rsaCipher.wrap(aesKey);

        // Base64 encode the encrypted data
        String encryptedXml = Base64.getEncoder().encodeToString(encryptedXmlBytes);
        String encryptedAesKey = Base64.getEncoder().encodeToString(encryptedAesKeyBytes);
        String ivBase64 = Base64.getEncoder().encodeToString(iv);

        // Print the encrypted data
        System.out.println("Encrypted XML: " + encryptedXml);
        System.out.println("Encrypted AES Key: " + encryptedAesKey);
        System.out.println("IV: " + ivBase64);
    }
}
