package com.example.rest_service;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import javax.xml.bind.DatatypeConverter;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.StringWriter;
import java.security.*;
import java.util.Base64;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class usernameToken {

  static {
      Security.addProvider(new BouncyCastleProvider());
  }

  public static void main(String[] args) throws Exception {
      // Sample username and password
      String username = "B000200206";
      String password = "12345678";

      // Concatenate username and password to create the plaintext of UsernameToken
      String usernameToken = username + password;
      System.out.println("UsernameToken: " + usernameToken);

      // Compute SHA1 digest of the UsernameToken
      byte[] digest = computeDigest(usernameToken);
      System.out.println("Digest (Base64): " + Base64.getEncoder().encodeToString(digest));

      // Generate RSA key pair
      KeyPairGenerator keyPairGen = KeyPairGenerator.getInstance("RSA");
      keyPairGen.initialize(2048);
      KeyPair keyPair = keyPairGen.generateKeyPair();
      PublicKey publicKey = keyPair.getPublic();
      PrivateKey privateKey = keyPair.getPrivate();

      // Sign the digest using RSA-SHA1
      byte[] signature = signDigest(digest, privateKey);
      System.out.println("Signature (Base64): " + Base64.getEncoder().encodeToString(signature));

      // Create XML structure
      String xml = createXMLStructure(digest, signature);
      System.out.println("XML Structure: \n" + xml);
  }

  private static byte[] computeDigest(String data) throws Exception {
      MessageDigest digest = MessageDigest.getInstance("SHA-1");
      return digest.digest(data.getBytes("UTF-8"));
  }

  private static byte[] signDigest(byte[] digest, PrivateKey privateKey) throws Exception {
      Signature signature = Signature.getInstance("SHA1withRSA");
      signature.initSign(privateKey);
      signature.update(digest);
      return signature.sign();
  }

  private static String createXMLStructure(byte[] digest, byte[] signature) throws Exception {
      DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
      DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
      Document doc = docBuilder.newDocument();

      // Create Signature element
      Element signatureElement = doc.createElement("Signature");
      doc.appendChild(signatureElement);

      // Create SignatureMethod element
      Element signatureMethod = doc.createElement("SignatureMethod");
      signatureMethod.setAttribute("Algorithm", "http://www.w3.org/2000/09/xmldsig#rsa-sha1");
      signatureElement.appendChild(signatureMethod);

      // Create Reference element
      Element reference = doc.createElement("Reference");
      reference.setAttribute("URI", "#UsernameToken");
      signatureElement.appendChild(reference);

      // Create DigestMethod element
      Element digestMethod = doc.createElement("DigestMethod");
      digestMethod.setAttribute("Algorithm", "http://www.w3.org/2000/09/xmldsig#sha1");
      reference.appendChild(digestMethod);

      // Create DigestValue element
      Element digestValue = doc.createElement("DigestValue");
      digestValue.appendChild(doc.createTextNode(Base64.getEncoder().encodeToString(digest)));
      reference.appendChild(digestValue);

      // Create SignatureValue element
      Element signatureValue = doc.createElement("SignatureValue");
      signatureValue.appendChild(doc.createTextNode(Base64.getEncoder().encodeToString(signature)));
      signatureElement.appendChild(signatureValue);

      // Transform document to string
      TransformerFactory transformerFactory = TransformerFactory.newInstance();
      Transformer transformer = transformerFactory.newTransformer();
      DOMSource source = new DOMSource(doc);
      StringWriter writer = new StringWriter();
      StreamResult result = new StreamResult(writer);
      transformer.transform(source, result);

      return writer.toString();
  }
}