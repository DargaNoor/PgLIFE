
package com.example.rest_service;
////
/////**
//// * Hello world!
//// *
//// */
////public class App 
////{
////    public static void main( String[] args )
////    {
////        System.out.println( "Hello World!" );
////    }
////}
//
//
//import javax.crypto.Cipher;
//
//import org.bouncycastle.asn1.x500.X500Name;
//
//import java.io.FileInputStream;
//import java.io.FileOutputStream;
//import java.security.*;
//import java.security.cert.Certificate;
//import java.security.cert.X509Certificate;
//import java.util.Base64;
//
//import java.util.Date;
//
//public class App {
//
//    public static void main(String[] args) throws Exception {
//     
//    	String keystoreFilePath = "src/main/resources/keystore.jks";
//    	String keystorePassword = "keystorePassword";
//    	String keyAlias = "keyAlias";
//    	String keyPassword = "keyPassword";
//    	generateKeyPairAndStoreInJKS(keystoreFilePath, keystorePassword, keyAlias, keyPassword);
//
//
//        // Step 2: Encrypt the plaintext XML using the generated key pair
//        String plaintextXml = "<root><data>Some sensitive information</data></root>";
//        String encryptedXml = encryptXml(plaintextXml, keystoreFilePath, keystorePassword, keyAlias);
//
//        // Step 3: Output the encrypted XML
//        System.out.println("Encrypted XML:");
//        System.out.println(encryptedXml);
//    }
//
//    private static void generateKeyPairAndStoreInJKS(String keystoreFilePath, String keystorePassword,
//                                                      String keyAlias, String keyPassword) throws Exception {
//        KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA");
//        keyPairGenerator.initialize(2048);
//        KeyPair keyPair = keyPairGenerator.generateKeyPair();
//
//        KeyStore keyStore = KeyStore.getInstance("JKS");
//        keyStore.load(null, null);
//        X509Certificate certificate = generateSelfSignedCertificate(keyPair);
//        
//        keyStore.setKeyEntry(keyAlias, keyPair.getPrivate(), keyPassword.toCharArray(), new Certificate[]{certificate});
//try (FileOutputStream fos = new FileOutputStream(keystoreFilePath)) {
//            keyStore.store(fos, keystorePassword.toCharArray());
//        }
//    }
//    private static X509Certificate generateSelfSignedCertificate(KeyPair keyPair) throws Exception {
//        X509CertInfo info = new X509CertInfo();
//        info.set(X509CertInfo.SUBJECT, new X500Name("CN=example"));
//        info.set(X509CertInfo.ISSUER, new X500Name("CN=example"));
//        info.set(X509CertInfo.KEY, new CertificateX509Key(keyPair.getPublic()));
//        info.set(X509CertInfo.VERSION, new CertificateVersion(CertificateVersion.V3));
//        info.set(X509CertInfo.SERIAL_NUMBER, new CertificateSerialNumber(1));
//        info.set(X509CertInfo.VALIDITY, new CertificateValidity(new Date(), new Date(System.currentTimeMillis() + 365 * 24 * 60 * 60 * 1000)));
//        info.set(X509CertInfo.ALGORITHM_ID, new CertificateAlgorithmId(new AlgorithmId(AlgorithmId.sha256WithRSAEncryption_oid)));
//
//        // Create a new certificate signed by itself
//        X509CertImpl cert = new X509CertImpl(info);
//        cert.sign(keyPair.getPrivate(), "SHA256withRSA");
//
//        return cert;
//    }
//    private static String encryptXml(String plaintextXml, String keystoreFilePath, String keystorePassword, String keyAlias) throws Exception {
//        KeyStore keyStore = KeyStore.getInstance("JKS");
//        try (FileInputStream fis = new FileInputStream(keystoreFilePath)) {
//            keyStore.load(fis, keystorePassword.toCharArray());
//        }
//        PublicKey publicKey = keyStore.getCertificate(keyAlias).getPublicKey();
//
//        Cipher cipher = Cipher.getInstance("RSA/ECB/OAEPWithSHA-256AndMGF1Padding");
//        cipher.init(Cipher.ENCRYPT_MODE, publicKey);
//
//        byte[] encryptedBytes = cipher.doFinal(plaintextXml.getBytes());
//
//        return Base64.getEncoder().encodeToString(encryptedBytes);
//    }
//}
//
//
//import javax.crypto.Cipher;
//import javax.security.auth.x500.X500Principal;
//
//import org.bouncycastle.x509.X509V3CertificateGenerator;
//
//import java.io.FileInputStream;
//import java.io.FileOutputStream;
//import java.security.*;
//import java.security.cert.Certificate;
//import java.security.cert.CertificateFactory;
//import java.security.cert.X509Certificate;
//import java.util.Base64;
//import java.util.Date;
//import java.math.BigInteger;
//
//
//public class App {
//
//    public static void main(String[] args) throws Exception {
//
//        String keystoreFilePath = "src/main/resources/keystore.jks";
//        String keystorePassword = "keystorePassword";
//        String keyAlias = "keyAlias";
//        String keyPassword = "keyPassword";
//        generateKeyPairAndStoreInJKS(keystoreFilePath, keystorePassword, keyAlias, keyPassword);
//
//        // Step 2: Encrypt the plaintext XML using the generated key pair
//        String plaintextXml = "<root><data>Some sensitive information</data></root>";
//        String encryptedXml = encryptXml(plaintextXml, keystoreFilePath, keystorePassword, keyAlias);
//
//        // Step 3: Output the encrypted XML
//        System.out.println("Encrypted XML:");
//        System.out.println(encryptedXml);
//    }
//
//    private static void generateKeyPairAndStoreInJKS(String keystoreFilePath, String keystorePassword,
//                                                      String keyAlias, String keyPassword) throws Exception {
//        KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA");
//        keyPairGenerator.initialize(2048);
//        KeyPair keyPair = keyPairGenerator.generateKeyPair();
//
//        X509Certificate certificate = generateSelfSignedCertificate(keyPair);
//
//        KeyStore keyStore = KeyStore.getInstance("JKS");
//        keyStore.load(null, null);
//        keyStore.setKeyEntry(keyAlias, keyPair.getPrivate(), keyPassword.toCharArray(), new Certificate[]{certificate});
//
//        try (FileOutputStream fos = new FileOutputStream(keystoreFilePath)) {
//            keyStore.store(fos, keystorePassword.toCharArray());
//        }
//    }
//
//    private static X509Certificate generateSelfSignedCertificate(KeyPair keyPair) throws Exception {
//        PublicKey publicKey = keyPair.getPublic();
//        PrivateKey privateKey = keyPair.getPrivate();
//
//        // Generate a new X.509 certificate instance
//        X509Certificate cert = null;
//
//        try {
//            // Create a new X.509 certificate generator
//            CertificateFactory certFactory = CertificateFactory.getInstance("X.509");
//            X509V3CertificateGenerator certGenerator = new X509V3CertificateGenerator();
//
//            // Set certificate information
//            X500Principal subjectName = new X500Principal("CN=example");
//            certGenerator.setSerialNumber(BigInteger.valueOf(System.currentTimeMillis()));
//            certGenerator.setSubjectDN(subjectName);
//            certGenerator.setIssuerDN(subjectName); // Self-signed
//            certGenerator.setPublicKey(publicKey);
//            certGenerator.setNotBefore(new Date());
//            certGenerator.setNotAfter(new Date(System.currentTimeMillis() + 365 * 24 * 60 * 60 * 1000)); // Valid for 1 year
//            certGenerator.setSignatureAlgorithm("SHA256WithRSAEncryption");
//
//            // Generate the certificate
//            cert = certGenerator.generate(privateKey);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//
//        return cert;
//    }
//
//    private static String encryptXml(String plaintextXml, String keystoreFilePath, String keystorePassword, String keyAlias) throws Exception {
//        KeyStore keyStore = KeyStore.getInstance("JKS");
//        try (FileInputStream fis = new FileInputStream(keystoreFilePath)) {
//            keyStore.load(fis, keystorePassword.toCharArray());
//        }
//        PublicKey publicKey = keyStore.getCertificate(keyAlias).getPublicKey();
//
//        Cipher cipher = Cipher.getInstance("RSA/ECB/OAEPWithSHA-256AndMGF1Padding");
//        cipher.init(Cipher.ENCRYPT_MODE, publicKey);
//
//        byte[] encryptedBytes = cipher.doFinal(plaintextXml.getBytes());
//
//        return Base64.getEncoder().encodeToString(encryptedBytes);
//    }
//}

//import java.io.StringWriter;

//
//import org.bouncycastle.jce.provider.BouncyCastleProvider;
//import org.bouncycastle.x509.X509V3CertificateGenerator;
//
//import javax.crypto.Cipher;
//import javax.security.auth.x500.X500Principal;
//import java.io.FileInputStream;
//import java.io.FileOutputStream;
//import java.security.*;
//import java.security.cert.Certificate;
//import java.security.cert.CertificateFactory;
//import java.security.cert.X509Certificate;
//import java.util.Base64;
//import java.util.Date;
//import java.math.BigInteger;
//
//public class App {
//
//    public static void main(String[] args) throws Exception {
//        Security.addProvider(new BouncyCastleProvider());
//
//        String keystoreFilePath = "src/main/resources/keystore.jks";
//        String keystorePassword = "keystorePassword";
//        String keyAlias = "keyAlias";
//        String keyPassword = "keyPassword";
//        generateKeyPairAndStoreInJKS(keystoreFilePath, keystorePassword, keyAlias, keyPassword);
//
//        // Step 2: Encrypt the plaintext XML using the generated key pair
//        String plaintextXml = "<root><data>Some sensitive information</data></root>";
//        String encryptedXml = encryptXml(plaintextXml, keystoreFilePath, keystorePassword, keyAlias);
//
//        // Step 3: Output the encrypted XML
//        System.out.println("Encrypted XML:");
//        System.out.println(encryptedXml);
//    }
//
//    private static void generateKeyPairAndStoreInJKS(String keystoreFilePath, String keystorePassword,
//                                                      String keyAlias, String keyPassword) throws Exception {
//        KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA");
//        keyPairGenerator.initialize(2048);
//        KeyPair keyPair = keyPairGenerator.generateKeyPair();
//
//        X509Certificate certificate = generateSelfSignedCertificate(keyPair);
//
//        KeyStore keyStore = KeyStore.getInstance("JKS");
//        keyStore.load(null, null);
//        keyStore.setKeyEntry(keyAlias, keyPair.getPrivate(), keyPassword.toCharArray(), new Certificate[]{certificate});
//
//        try (FileOutputStream fos = new FileOutputStream(keystoreFilePath)) {
//            keyStore.store(fos, keystorePassword.toCharArray());
//        }
//    }
//
//    private static X509Certificate generateSelfSignedCertificate(KeyPair keyPair) throws Exception {
//        PublicKey publicKey = keyPair.getPublic();
//        PrivateKey privateKey = keyPair.getPrivate();
//
//        // Generate a new X.509 certificate instance
//        X509Certificate cert = null;
//
//        try {
//            // Create a new X.509 certificate generator
//            CertificateFactory certFactory = CertificateFactory.getInstance("X.509");
//            X509V3CertificateGenerator certGenerator = new X509V3CertificateGenerator();
//
//            // Set certificate information
//            X500Principal subjectName = new X500Principal("CN=example");
//            certGenerator.setSerialNumber(BigInteger.valueOf(System.currentTimeMillis()));
//            certGenerator.setSubjectDN(subjectName);
//            certGenerator.setIssuerDN(subjectName); // Self-signed
//            certGenerator.setPublicKey(publicKey);
//            certGenerator.setNotBefore(new Date());
//            certGenerator.setNotAfter(new Date(System.currentTimeMillis() + 365 * 24 * 60 * 60 * 1000)); // Valid for 1 year
//            certGenerator.setSignatureAlgorithm("SHA256WithRSAEncryption");
//
//            // Generate the certificate
//            cert = certGenerator.generate(privateKey);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//
//        return cert;
//    }
//
//    private static String encryptXml(String plaintextXml, String keystoreFilePath, String keystorePassword, String keyAlias) throws Exception {
//        KeyStore keyStore = KeyStore.getInstance("JKS");
//        try (FileInputStream fis = new FileInputStream(keystoreFilePath)) {
//            keyStore.load(fis, keystorePassword.toCharArray());
//        }
//        PublicKey publicKey = keyStore.getCertificate(keyAlias).getPublicKey();
//
//        Cipher cipher = Cipher.getInstance("RSA/ECB/OAEPWithSHA-256AndMGF1Padding");
//        cipher.init(Cipher.ENCRYPT_MODE, publicKey);
//
//        byte[] encryptedBytes = cipher.doFinal(plaintextXml.getBytes());
//
//        return Base64.getEncoder().encodeToString(encryptedBytes);
//    }
//}

//import org.bouncycastle.jce.provider.BouncyCastleProvider;
//import org.bouncycastle.util.Arrays;
//import org.bouncycastle.x509.X509V3CertificateGenerator;
//
//import javax.crypto.Cipher;
//import javax.crypto.KeyGenerator;
//import javax.crypto.SecretKey;
//import javax.crypto.spec.SecretKeySpec;
//import javax.security.auth.x500.X500Principal;
//import java.io.FileInputStream;
//import java.io.FileOutputStream;
//import java.security.*;
//import java.security.cert.Certificate;
//import java.security.cert.CertificateFactory;
//import java.security.cert.X509Certificate;
//import java.util.Base64;
//import java.util.Date;
//import java.math.BigInteger;
//
//public class App {
//
//    public static void main(String[] args) throws Exception {
//        Security.addProvider(new BouncyCastleProvider());
//
//        String keystoreFilePath = "src/main/resources/keystore.jks";
//        String keystorePassword = "keystorePassword";
//        String keyAlias = "keyAlias";
//        String keyPassword = "keyPassword";
//        generateKeyPairAndStoreInJKS(keystoreFilePath, keystorePassword, keyAlias, keyPassword);
//
//        // Step 2: Encrypt the plaintext XML using the generated key pair
//        String plaintextXml = "<SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ds=\"http://www.w3.org/2000/09/xmldsig#\" xmlns:wsse=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd\" xmlns:wsu=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\">\n" +
//                "\t<SOAP-ENV:Header>\n" +
//                "\t      <wsse:Security mustUnderstand=\"1\">\n" +
//                "\t\t<wsse:UsernameToken>\n" +
//                "\t\t\t<wsse:Username>B000200206</wsse:Username>\n" +
//                "\t\t</wsse:UsernameToken>\n" +
//                "        \t<wsu:Timestamp>\n" +
//                "\t\t\t<wsu:Created>30</wsu:Created>\n" +
//                "\t\t\t<wsu:Expires>30</wsu:Expires>\n" +
//                "\t\t</wsu:Timestamp>\n" +
//                "        \t<ds:Signature>\n" +
//                "\t  \t\t<ds:SignedInfo>\n" +
//                "\t      \t\t\t<ds:CanonicalizationMethod Algorithm=\"http://www.w3.org/TR/2001/REC-xml-c14n-20010315\"/>\n" +
//                "\t      \t\t\t<ds:SignatureMethod Algorithm=\"http://www.w3.org/2000/09/xmldsig#rsa-sha1\"/>\n" +
//                "\t  \t\t</ds:SignedInfo>\n" +
//                "\t\t</ds:Signature>\n" +
//                "\t   \t\t</wsse:Security>\n" +
//                "\t</SOAP-ENV:Header>\n" +
//                "\t<SOAP-ENV:Body/>\n" +
//                "</SOAP-ENV:Envelope>";
//
//        String encryptedXml = encryptXml(plaintextXml, keystoreFilePath, keystorePassword, keyAlias);
//        System.out.println(decryptXml(encryptedXml, keystoreFilePath, keystorePassword, keyAlias, keyPassword));
//        // Step 3: Output the encrypted XML
//        System.out.println("Encrypted XML:");
//        System.out.println(encryptedXml);
//    }
//
//    private static void generateKeyPairAndStoreInJKS(String keystoreFilePath, String keystorePassword,
//                                                      String keyAlias, String keyPassword) throws Exception {
//        KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA");
//        keyPairGenerator.initialize(2048);
//        KeyPair keyPair = keyPairGenerator.generateKeyPair();
//
//        X509Certificate certificate = generateSelfSignedCertificate(keyPair);
//
//        KeyStore keyStore = KeyStore.getInstance("JKS");
//        keyStore.load(null, null);
//        keyStore.setKeyEntry(keyAlias, keyPair.getPrivate(), keyPassword.toCharArray(), new Certificate[]{certificate});
//
//        try (FileOutputStream fos = new FileOutputStream(keystoreFilePath)) {
//            keyStore.store(fos, keystorePassword.toCharArray());
//        }
//    }
//
//    private static X509Certificate generateSelfSignedCertificate(KeyPair keyPair) throws Exception {
//        PublicKey publicKey = keyPair.getPublic();
//        PrivateKey privateKey = keyPair.getPrivate();
//
//        // Generate a new X.509 certificate instance
//        X509Certificate cert = null;
//
//        try {
//            // Create a new X.509 certificate generator
//            CertificateFactory certFactory = CertificateFactory.getInstance("X.509");
//            X509V3CertificateGenerator certGenerator = new X509V3CertificateGenerator();
//
//            // Set certificate information
//            X500Principal subjectName = new X500Principal("CN=example");
//            certGenerator.setSerialNumber(BigInteger.valueOf(System.currentTimeMillis()));
//            certGenerator.setSubjectDN(subjectName);
//            certGenerator.setIssuerDN(subjectName); // Self-signed
//            certGenerator.setPublicKey(publicKey);
//            certGenerator.setNotBefore(new Date());
//            certGenerator.setNotAfter(new Date(System.currentTimeMillis() + 365 * 24 * 60 * 60 * 1000)); // Valid for 1 year
//            certGenerator.setSignatureAlgorithm("SHA256WithRSAEncryption");
//
//            // Generate the certificate
//            cert = certGenerator.generate(privateKey);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//
//        return cert;
//    }
//
//    private static String encryptXml(String plaintextXml, String keystoreFilePath, String keystorePassword, String keyAlias) throws Exception {
//        KeyStore keyStore = KeyStore.getInstance("JKS");
//        try (FileInputStream fis = new FileInputStream(keystoreFilePath)) {
//            keyStore.load(fis, keystorePassword.toCharArray());
//        }
//        PublicKey publicKey = keyStore.getCertificate(keyAlias).getPublicKey();
//
//        // Generate a symmetric key for encrypting the XML data
//        KeyGenerator keyGen = KeyGenerator.getInstance("AES");
//        keyGen.init(256);
//        SecretKey secretKey = keyGen.generateKey();
//
//        // Encrypt the XML data symmetrically
//        Cipher symmetricCipher = Cipher.getInstance("AES");
//        symmetricCipher.init(Cipher.ENCRYPT_MODE, secretKey);
//        byte[] encryptedXmlBytes = symmetricCipher.doFinal(plaintextXml.getBytes());
//
//        // Encrypt the symmetric key with the RSA public key
//        Cipher rsaCipher = Cipher.getInstance("RSA/ECB/OAEPWithSHA-256AndMGF1Padding");
//        rsaCipher.init(Cipher.ENCRYPT_MODE, publicKey);
//        byte[] encryptedKeyBytes = rsaCipher.doFinal(secretKey.getEncoded());
//
//        // Concatenate the encrypted key and the encrypted XML data
//        byte[] encryptedData = new byte[encryptedKeyBytes.length + encryptedXmlBytes.length];
//        System.arraycopy(encryptedKeyBytes, 0, encryptedData, 0, encryptedKeyBytes.length);
//        System.arraycopy(encryptedXmlBytes, 0, encryptedData, encryptedKeyBytes.length, encryptedXmlBytes.length);
//
//        // Encode the concatenated bytes to Base64
//        return Base64.getEncoder().encodeToString(encryptedData);
//    }
//
//    private static String decryptXml(String encryptedXml, String keystoreFilePath, String keystorePassword, String keyAlias, String keyPassword) throws Exception {
//        KeyStore keyStore = KeyStore.getInstance("JKS");
//        try (FileInputStream fis = new FileInputStream(keystoreFilePath)) {
//            keyStore.load(fis, keystorePassword.toCharArray());
//        }
//        PrivateKey privateKey = (PrivateKey) keyStore.getKey(keyAlias, keyPassword.toCharArray());
//
//        // Decode the Base64-encoded string
//        byte[] encryptedData = Base64.getDecoder().decode(encryptedXml);
//
//        // Separate the encrypted key and the encrypted XML data
//        int rsaKeySize = 2048;
//        int encryptedKeyLength = rsaKeySize / 8; // Length of the encrypted AES key
//        byte[] encryptedKeyBytes = Arrays.copyOfRange(encryptedData, 0, encryptedKeyLength);
//        byte[] encryptedXmlBytes = Arrays.copyOfRange(encryptedData, encryptedKeyLength, encryptedData.length);
//
//        // Decrypt the symmetric key with the RSA private key
//        Cipher rsaCipher = Cipher.getInstance("RSA/ECB/OAEPWithSHA-256AndMGF1Padding");
//        rsaCipher.init(Cipher.DECRYPT_MODE, privateKey);
//        byte[] decryptedKeyBytes = rsaCipher.doFinal(encryptedKeyBytes);
//        SecretKey secretKey = new SecretKeySpec(decryptedKeyBytes, "AES");
//
//        // Decrypt the XML data symmetrically
//        Cipher symmetricCipher = Cipher.getInstance("AES");
//        symmetricCipher.init(Cipher.DECRYPT_MODE, secretKey);
//        byte[] decryptedXmlBytes = symmetricCipher.doFinal(encryptedXmlBytes);
//
//        // Convert the decrypted bytes to string
//        return new String(decryptedXmlBytes);
//    }
//}

//import org.apache.wss4j.common.crypto.CryptoFactory;
//import org.apache.wss4j.common.ext.WSSecurityException;
//import org.apache.wss4j.common.util.Loader;
//import org.apache.wss4j.dom.WSConstants;
//import org.apache.wss4j.dom.WSDataRef;
//import org.apache.wss4j.dom.handler.WSHandlerConstants;
//import org.apache.wss4j.dom.message.WSSecHeader;
//import org.apache.wss4j.dom.message.WSSecSignature;
//import org.apache.wss4j.dom.message.WSSecEncrypt;
//import org.apache.wss4j.dom.message.WSSecUsernameToken;
//import org.apache.wss4j.dom.util.WSSecurityUtil;
//import org.w3c.dom.Document;
//import org.w3c.dom.Element;
//import org.apache.wss4j.common.crypto.Crypto;
//
//import javax.crypto.SecretKey;
//import javax.xml.parsers.DocumentBuilder;
//import javax.xml.parsers.DocumentBuilderFactory;
//import javax.xml.transform.OutputKeys;
//import javax.xml.transform.Transformer;
//import javax.xml.transform.TransformerFactory;
//import javax.xml.transform.dom.DOMSource;
//import javax.xml.transform.stream.StreamResult;
//import java.io.StringWriter;
//import java.util.List;
//
//import org.apache.wss4j.dom.WSDocInfo;
//import org.apache.wss4j.dom.engine.WSSConfig;
//
//import javax.xml.parsers.ParserConfigurationException;
//import java.security.cert.CertificateException;
//import java.security.cert.X509Certificate;
//
//
//public class App {
//
//    public static void main(String[] args) throws Exception {
//        // Load the plain XML request
//        String plainXML = "<SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" " +
//                "xmlns:ds=\"http://www.w3.org/2000/09/xmldsig#\" " +
//                "xmlns:wsse=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd\" " +
//                "xmlns:wsu=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\">" +
//                "<SOAP-ENV:Header><wsse:Security mustUnderstand=\"1\">" +
//                "<wsse:UsernameToken><wsse:Username>B000200206</wsse:Username></wsse:UsernameToken>" +
//                "<wsu:Timestamp><wsu:Created>2024-05-19T00:00:30Z</wsu:Created>" +
//                "<wsu:Expires>2024-05-19T00:00:60Z</wsu:Expires></wsu:Timestamp>" +
//                "<ds:Signature><ds:SignedInfo>" +
//                "<ds:CanonicalizationMethod Algorithm=\"http://www.w3.org/TR/2001/REC-xml-c14n-20010315\"/>" +
//                "<ds:SignatureMethod Algorithm=\"http://www.w3.org/2000/09/xmldsig#rsa-sha1\"/>" +
//                "</ds:SignedInfo></ds:Signature></wsse:Security></SOAP-ENV:Header><SOAP-ENV:Body/></SOAP-ENV:Envelope>";
//
//        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
//        dbf.setNamespaceAware(true);
//        DocumentBuilder db = dbf.newDocumentBuilder();
//        Document document = db.parse(new java.io.ByteArrayInputStream(plainXML.getBytes()));
//
//        // Load the keystore
//        Crypto crypto = CryptoFactory.getInstance("crypto.properties");
//
//        // Encrypt and sign the document
//        WSSEncryptAndSignExample example = new WSSEncryptAndSignExample();
//        Document encryptedAndSignedDoc = example.encryptAndSignDocument();
//        System.out.println(encryptedAndSignedDoc);
//
//        // Print the encrypted document
//        TransformerFactory tf = TransformerFactory.newInstance();
//        Transformer transformer = tf.newTransformer();
//        transformer.setOutputProperty(OutputKeys.INDENT, "yes");
//        StringWriter writer = new StringWriter();
//        transformer.transform(new DOMSource(encryptedAndSignedDoc), new StreamResult(writer));
//        System.out.println(writer.toString());
//    }

//    private static Document encryptAndSignDocument(Document doc, Crypto crypto) throws WSSecurityException {
//        WSSecHeader secHeader = new WSSecHeader(doc);
//        secHeader.insertSecurityHeader();
//
//        // Create a UsernameToken
//        WSSecUsernameToken usernameToken = new WSSecUsernameToken(secHeader);
//        usernameToken.setUserInfo("B000200206", "abcdefgh12");
//        usernameToken.build();
//
//        // Signature
//        WSSecSignature signature = new WSSecSignature( secHeader);
//        signature.setUserInfo("uat", "Abc@1234");
//        signature.setKeyIdentifierType(WSConstants.BST_DIRECT_REFERENCE); // Binary Security Token
//        signature.build(crypto);
//
//        // Encryption
//        WSSecEncrypt encryption = new WSSecEncrypt(doc);
//        encryption.setUserInfo("uat", "Abc@1234");
//        encryption.setKeyIdentifierType(WSConstants.BST_DIRECT_REFERENCE); // Binary Security Token
//        List<WSDataRef> references = encryption.build( crypto,);
//
//        WSSecurityUtil.prependChildElement(secHeader.getSecurityHeader(), (Element) references.get(0).getProtectedElement().getParentNode());
//
//        return doc;
//    }
//    public Document encryptAndSignDocument() throws Exception {
//        Document doc = createDocument();
//        WSSConfig.init();
//
//        // Create a security header
//        WSSecHeader secHeader = new WSSecHeader(doc);
//        secHeader.insertSecurityHeader();
//
//        // Create a UsernameToken
//        WSSecUsernameToken usernameToken = new WSSecUsernameToken();
//        usernameToken.setUserInfo("B000200206", "abcdefgh12");
//        usernameToken.build(doc, secHeader);
//
//        // Signature
//        WSSecSignature signature = new WSSecSignature();
//        signature.setUserInfo("uat", "Abc@1234");
//        signature.setKeyIdentifierType(WSConstants.X509_KEY_IDENTIFIER);
//        signature.build(doc, null, secHeader);
//
//        // Encryption
//        WSSecEncrypt encryption = new WSSecEncrypt();
//        encryption.setUserInfo("uat", "Abc@1234");
//        encryption.setKeyIdentifierType(WSConstants.X509_KEY_IDENTIFIER);
//        encryption.build(doc, null, secHeader);
//
//        List<javax.xml.crypto.dsig.Reference> referenceList = encryption.encrypt();
//
//        WSSecurityUtil.prependChildElement(secHeader.getSecurityHeader(), referenceList.get(0).getElement());
//
//        return doc;
//    }
//
//    private Document createDocument() throws ParserConfigurationException {
//        return DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();
//    }
//
//
//}
//    	

//
//import org.bouncycastle.jce.provider.BouncyCastleProvider;
//
//import javax.crypto.Cipher;
//import javax.crypto.KeyGenerator;
//import javax.crypto.SecretKey;
//import java.security.KeyFactory;
//import java.security.KeyPair;
//import java.security.KeyPairGenerator;
//import java.security.PublicKey;
//import java.security.Security;
//import java.security.spec.X509EncodedKeySpec;
//import java.util.Base64;
//
//public class App {
//
//    static {
//        // Add BouncyCastle as a security provider
//        Security.addProvider(new BouncyCastleProvider());
//    }
//
//    public static void main(String[] args) throws Exception {
//        // Generate a symmetric key (AES key in this case)
//        KeyGenerator keyGen = KeyGenerator.getInstance("AES");
//        keyGen.init(256);
//        SecretKey symmetricKey = keyGen.generateKey();
//
//        // Generate an RSA key pair
//        KeyPairGenerator keyPairGen = KeyPairGenerator.getInstance("RSA");
//        keyPairGen.initialize(2048);
//        KeyPair keyPair = keyPairGen.generateKeyPair();
//        PublicKey publicKey = keyPair.getPublic();
//
//        // Encrypt the symmetric key using RSA-OAEP with MGF1
//        byte[] encryptedKey = encryptKeyWithRSAOAEP(symmetricKey.getEncoded(), publicKey);
//
//        // Encode the encrypted key as Base64 for inclusion in an XML element
//        String cipherValue = Base64.getEncoder().encodeToString(encryptedKey);
//        System.out.println("EncryptedKey CipherValue: " + cipherValue);
//    }
//
//    public static byte[] encryptKeyWithRSAOAEP(byte[] key, PublicKey publicKey) throws Exception {
//        Cipher cipher = Cipher.getInstance("RSA/ECB/OAEPPadding", "BC");
//        cipher.init(Cipher.ENCRYPT_MODE, publicKey);
//        return cipher.doFinal(key);
//    }
//}


//import org.bouncycastle.asn1.x500.X500Name;
//import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
//import org.bouncycastle.asn1.x509.SubjectPublicKeyInfo;
//import org.bouncycastle.cert.X509v3CertificateBuilder;
//import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter;
//import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder;
//import org.bouncycastle.jce.provider.BouncyCastleProvider;
//import org.bouncycastle.operator.ContentSigner;
//import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder;
//import org.bouncycastle.operator.jcajce.JcaDigestCalculatorProviderBuilder;
//
//import java.math.BigInteger;
//import java.security.KeyPair;
//import java.security.KeyPairGenerator;
//import java.security.PublicKey;
//import java.security.Security;
//import java.security.cert.X509Certificate;
//import java.util.Base64;
//import java.util.Date;
//
//public class App{
//
//    static {
//        // Add BouncyCastle as a security provider
//        Security.addProvider(new BouncyCastleProvider());
//    }
//
//    public static void main(String[] args) throws Exception {
//        // Generate an RSA key pair
//        KeyPairGenerator keyPairGen = KeyPairGenerator.getInstance("RSA");
//        keyPairGen.initialize(2048);
//        KeyPair keyPair = keyPairGen.generateKeyPair();
//
//        // Generate a self-signed certificate
//        X509Certificate certificate = generateSelfSignedCertificate(keyPair);
//
//        // Print the certificate in PEM format
//        String certificatePEM = convertToPEM(certificate);
//        System.out.println("Generated Certificate:");
//        System.out.println(certificatePEM);
//    }
//
//    public static X509Certificate generateSelfSignedCertificate(KeyPair keyPair) throws Exception {
//        // Set certificate attributes
//        X500Name issuerName = new X500Name("CN=Test Certificate");
//        BigInteger serialNumber = BigInteger.valueOf(System.currentTimeMillis());
//        Date startDate = new Date();
//        Date endDate = new Date(System.currentTimeMillis() + 365L * 24 * 60 * 60 * 1000); // 1 year validity
//        PublicKey publicKey = keyPair.getPublic();
//
//        // Create the certificate
//        X509v3CertificateBuilder certBuilder = new JcaX509v3CertificateBuilder(
//                issuerName, serialNumber, startDate, endDate, issuerName, publicKey
//        );
//
//        ContentSigner contentSigner = new JcaContentSignerBuilder("SHA256WithRSA").build(keyPair.getPrivate());
//        return new JcaX509CertificateConverter().setProvider("BC")
//                .getCertificate(certBuilder.build(contentSigner));
//    }
//
//    public static String convertToPEM(X509Certificate certificate) throws Exception {
//        Base64.Encoder encoder = Base64.getMimeEncoder(64, "\n".getBytes());
//        String certEncoded = new String(encoder.encode(certificate.getEncoded()));
//        return "-----BEGIN CERTIFICATE-----\n" + certEncoded + "\n-----END CERTIFICATE-----";
//    }
//}


////---------------key encrypted-------------------------
//import org.bouncycastle.jce.provider.BouncyCastleProvider;
//
//import javax.crypto.Cipher;
//import javax.crypto.KeyGenerator;
//import javax.crypto.SecretKey;
//import java.security.KeyFactory;
//import java.security.PublicKey;
//import java.security.Security;
//import java.security.cert.CertificateFactory;
//import java.security.cert.X509Certificate;
//import java.util.Base64;
//
//public class App {
//
//    static {
//        // Add BouncyCastle as a security provider
//        Security.addProvider(new BouncyCastleProvider());
//    }
//
//    public static void main(String[] args) throws Exception {
//        // Generate a symmetric key (AES key in this case)
//        KeyGenerator keyGen = KeyGenerator.getInstance("AES");
//        keyGen.init(256);
//        SecretKey symmetricKey = keyGen.generateKey();
//
//        // Generated certificate string
//        String certificateString = "-----BEGIN CERTIFICATE-----\r\n"
//        		+ "MIICtDCCAZygAwIBAgIGAY+VvpDSMA0GCSqGSIb3DQEBCwUAMBsxGTAXBgNVBAMM\r\n"
//        		+ "EFRlc3QgQ2VydGlmaWNhdGUwHhcNMjQwNTIwMTEyNDA1WhcNMjUwNTIwMTEyNDA1\r\n"
//        		+ "WjAbMRkwFwYDVQQDDBBUZXN0IENlcnRpZmljYXRlMIIBIjANBgkqhkiG9w0BAQEF\r\n"
//        		+ "AAOCAQ8AMIIBCgKCAQEA0xG1w6kUTmlN6sk9poEOjeBbfALT2mIfC/rsDy8a+M1T\r\n"
//        		+ "RfMv0DFay6ycDHPhcOIQn25Ub+MOkcGzpOD1V7X2/VDwaDlSiqfDBS/1pgz9m5Z2\r\n"
//        		+ "fFlLjPI0B73RkfYQrM99ejPQobJKsiwATQhcx0yFJKeimT6Nk9wYo+VG+d+/Sed9\r\n"
//        		+ "N4cMrD+S0/CvRaXx7lkdeCmLtWLIQwEKmagK/qk9A/n+fFypdXMLgXuU0cnz6PRb\r\n"
//        		+ "8GpByNX+EqZ3XBgJmHu4OJuGyEGYhOII8Q16BQZczR9CwV0gZHBjycPWAjcxFYau\r\n"
//        		+ "CsZK59SNtXK09q7p8wud3f4NJC+7I6SGTF6LNKEmHQIDAQABMA0GCSqGSIb3DQEB\r\n"
//        		+ "CwUAA4IBAQBnFU091UabnP/wu+8w/2pNpVWvgqhhohFQpBZKhz0yATxYNfz3U1kp\r\n"
//        		+ "nQto8+LvFnxsxLCE0VZKeZmuk3y7OD0SxksWW6Xq/YwRjcLdbPnk3IWLuf62lPTo\r\n"
//        		+ "O25rYWmKZBiNIgiCmVNQKs0s71ZC74umP3l7GX9F3QTwkiQxpUzhRmf/HV9fj1k2\r\n"
//        		+ "T/v0JtB56e7fiffLZ4yTE6pWEabQfBLHAsXKnBDIZtTGK04FKrkmKmQqhMiNOvTR\r\n"
//        		+ "5mOdeAShP7P3fMEwxQxsVeJHvGzgQ+7njBDjrWxNaVA7t6IEkiPezdKw6RKv65FR\r\n"
//        		+ "Nm/udaOWAi2+C3etvXEoQswBk4vRWeY/\r\n"
//        		+ "-----END CERTIFICATE-----";
//
//        // Extract the public key from the certificate
//        PublicKey publicKey = getPublicKeyFromCertificate(certificateString);
//        System.out.println(publicKey);
//        // Encrypt the symmetric key using RSA-OAEP with MGF1
//        byte[] encryptedKey = encryptKeyWithRSAOAEP(symmetricKey.getEncoded(), publicKey);
//
//        // Encode the encrypted key as Base64 for inclusion in an XML element
//        String cipherValue = Base64.getEncoder().encodeToString(encryptedKey);
//        System.out.println("EncryptedKey CipherValue: " + cipherValue);
//    }
//
//    public static PublicKey getPublicKeyFromCertificate(String certString) throws Exception {
//        certString = certString.replace("-----BEGIN CERTIFICATE-----", "")
//                               .replace("-----END CERTIFICATE-----", "")
//                               .replaceAll("\\s", "");
//
//        byte[] certBytes = Base64.getDecoder().decode(certString);
//        CertificateFactory certificateFactory = CertificateFactory.getInstance("X.509");
//        X509Certificate certificate = (X509Certificate) certificateFactory.generateCertificate(new java.io.ByteArrayInputStream(certBytes));
//        return certificate.getPublicKey();
//    }
//
//    public static byte[] encryptKeyWithRSAOAEP(byte[] key, PublicKey publicKey) throws Exception {
//        Cipher cipher = Cipher.getInstance("RSA/ECB/OAEPWithSHA-256AndMGF1Padding", "BC");
//        cipher.init(Cipher.ENCRYPT_MODE, publicKey);
//        return cipher.doFinal(key);
//    }
//}
//
//----------------timestamp----------
//import org.bouncycastle.jce.provider.BouncyCastleProvider;
//
//import javax.xml.bind.DatatypeConverter;
//import javax.xml.parsers.DocumentBuilder;
//import javax.xml.parsers.DocumentBuilderFactory;
//import javax.xml.transform.Transformer;
//import javax.xml.transform.TransformerFactory;
//import javax.xml.transform.dom.DOMSource;
//import javax.xml.transform.stream.StreamResult;
//import java.io.StringWriter;
//import java.security.*;
//import java.util.Base64;
//import java.util.Date;
//import javax.crypto.Cipher;
//
//import org.w3c.dom.Document;
//import org.w3c.dom.Element;
//
//public class App {
//
//    static {
//        Security.addProvider(new BouncyCastleProvider());
//    }
//
//    public static void main(String[] args) throws Exception {
//        // Generate RSA key pair
//        KeyPairGenerator keyPairGen = KeyPairGenerator.getInstance("RSA");
//        keyPairGen.initialize(2048);
//        KeyPair keyPair = keyPairGen.generateKeyPair();
//        PublicKey publicKey = keyPair.getPublic();
//        PrivateKey privateKey = keyPair.getPrivate();
//
//        // Generate timestamp
////        String timestamp = generateTimestamp();
//        String timestamp = "2024-04-24T15:49:30.336Z";
//        System.out.println("Timestamp: " + timestamp);
//
//        // Compute SHA1 digest
//        byte[] digest = computeDigest(timestamp);
//        System.out.println("Digest (Base64): " + Base64.getEncoder().encodeToString(digest));
//
//        // Encrypt timestamp
//        byte[] encryptedTimestamp = encryptTimestamp(timestamp, publicKey);
//        System.out.println("Encrypted Timestamp (Base64): " + Base64.getEncoder().encodeToString(encryptedTimestamp));
//
//        // Sign the digest using RSA-SHA1
//        byte[] signature = signDigest(digest, privateKey);
//        System.out.println("Signature (Base64): " + Base64.getEncoder().encodeToString(signature));
//
//        // Create XML structure
//        String xml = createXMLStructure(timestamp, digest, encryptedTimestamp, signature);
//        System.out.println("XML Structure: \n" + xml);
//    }
//
//    private static String generateTimestamp() {
//        // Generate a simple timestamp
//        return Long.toString(new Date().getTime());
//    }
//
//    private static byte[] computeDigest(String data) throws Exception {
//        MessageDigest digest = MessageDigest.getInstance("SHA-1");
//        return digest.digest(data.getBytes("UTF-8"));
//    }
//
//    private static byte[] encryptTimestamp(String timestamp, PublicKey publicKey) throws Exception {
//        Cipher cipher = Cipher.getInstance("RSA/ECB/OAEPPadding", "BC");
//        cipher.init(Cipher.ENCRYPT_MODE, publicKey);
//        return cipher.doFinal(timestamp.getBytes("UTF-8"));
//    }
//
//    private static byte[] signDigest(byte[] digest, PrivateKey privateKey) throws Exception {
//        Signature signature = Signature.getInstance("SHA1withRSA");
//        signature.initSign(privateKey);
//        signature.update(digest);
//        return signature.sign();
//    }
//
//    private static String createXMLStructure(String timestamp, byte[] digest, byte[] encryptedTimestamp, byte[] signature) throws Exception {
//        DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
//        DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
//        Document doc = docBuilder.newDocument();
//
//        // Create Signature element
//        Element signatureElement = doc.createElement("Signature");
//        doc.appendChild(signatureElement);
//
//        // Create SignatureMethod element
//        Element signatureMethod = doc.createElement("SignatureMethod");
//        signatureMethod.setAttribute("Algorithm", "http://www.w3.org/2000/09/xmldsig#rsa-sha1");
//        signatureElement.appendChild(signatureMethod);
//
//        // Create Reference element
//        Element reference = doc.createElement("Reference");
//        reference.setAttribute("URI", "#TS");
//        signatureElement.appendChild(reference);
//
//        // Create DigestMethod element
//        Element digestMethod = doc.createElement("DigestMethod");
//        digestMethod.setAttribute("Algorithm", "http://www.w3.org/2000/09/xmldsig#sha1");
//        reference.appendChild(digestMethod);
//
//        // Create DigestValue element
//        Element digestValue = doc.createElement("DigestValue");
//        digestValue.appendChild(doc.createTextNode(Base64.getEncoder().encodeToString(digest)));
//        reference.appendChild(digestValue);
//
//        // Create EncryptedTimestamp element
//        Element encryptedTimestampElement = doc.createElement("EncryptedTimestamp");
//        encryptedTimestampElement.setAttribute("Algorithm", "http://www.w3.org/2001/04/xmlenc#rsa-oaep-mgf1p");
//        encryptedTimestampElement.appendChild(doc.createTextNode(Base64.getEncoder().encodeToString(encryptedTimestamp)));
//        signatureElement.appendChild(encryptedTimestampElement);
//
//        // Create SignatureValue element
//        Element signatureValue = doc.createElement("SignatureValue");
//        signatureValue.appendChild(doc.createTextNode(Base64.getEncoder().encodeToString(signature)));
//        signatureElement.appendChild(signatureValue);
//
//        // Transform document to string
//        TransformerFactory transformerFactory = TransformerFactory.newInstance();
//        Transformer transformer = transformerFactory.newTransformer();
//        DOMSource source = new DOMSource(doc);
//        StringWriter writer = new StringWriter();
//        StreamResult result = new StreamResult(writer);
//        transformer.transform(source, result);
//
//        return writer.toString();
//    }
//}
//import org.bouncycastle.jce.provider.BouncyCastleProvider;
//import javax.xml.bind.DatatypeConverter;
//import javax.xml.parsers.DocumentBuilder;
//import javax.xml.parsers.DocumentBuilderFactory;
//import javax.xml.transform.Transformer;
//import javax.xml.transform.TransformerFactory;
//import javax.xml.transform.dom.DOMSource;
//import javax.xml.transform.stream.StreamResult;
//import java.io.StringWriter;
//import java.security.*;
//import java.util.Base64;
//import org.w3c.dom.Document;
//import org.w3c.dom.Element;
//
//public class App {
//
//    static {
//        Security.addProvider(new BouncyCastleProvider());
//    }
//
//    public static void main(String[] args) throws Exception {
//        // Sample username and password
//        String username = "B000200206";
//        String password = "12345678";
//
//        // Concatenate username and password to create the plaintext of UsernameToken
//        String usernameToken = username + password;
//        System.out.println("UsernameToken: " + usernameToken);
//
//        // Compute SHA1 digest of the UsernameToken
//        byte[] digest = computeDigest(usernameToken);
//        System.out.println("Digest (Base64): " + Base64.getEncoder().encodeToString(digest));
//
//        // Generate RSA key pair
//        KeyPairGenerator keyPairGen = KeyPairGenerator.getInstance("RSA");
//        keyPairGen.initialize(2048);
//        KeyPair keyPair = keyPairGen.generateKeyPair();
//        PublicKey publicKey = keyPair.getPublic();
//        PrivateKey privateKey = keyPair.getPrivate();
//
//        // Sign the digest using RSA-SHA1
//        byte[] signature = signDigest(digest, privateKey);
//        System.out.println("Signature (Base64): " + Base64.getEncoder().encodeToString(signature));
//
//        // Create XML structure
//        String xml = createXMLStructure(digest, signature);
//        System.out.println("XML Structure: \n" + xml);
//    }
//
//    private static byte[] computeDigest(String data) throws Exception {
//        MessageDigest digest = MessageDigest.getInstance("SHA-1");
//        return digest.digest(data.getBytes("UTF-8"));
//    }
//
//    private static byte[] signDigest(byte[] digest, PrivateKey privateKey) throws Exception {
//        Signature signature = Signature.getInstance("SHA1withRSA");
//        signature.initSign(privateKey);
//        signature.update(digest);
//        return signature.sign();
//    }
//
//    private static String createXMLStructure(byte[] digest, byte[] signature) throws Exception {
//        DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
//        DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
//        Document doc = docBuilder.newDocument();
//
//        // Create Signature element
//        Element signatureElement = doc.createElement("Signature");
//        doc.appendChild(signatureElement);
//
//        // Create SignatureMethod element
//        Element signatureMethod = doc.createElement("SignatureMethod");
//        signatureMethod.setAttribute("Algorithm", "http://www.w3.org/2000/09/xmldsig#rsa-sha1");
//        signatureElement.appendChild(signatureMethod);
//
//        // Create Reference element
//        Element reference = doc.createElement("Reference");
//        reference.setAttribute("URI", "#UsernameToken");
//        signatureElement.appendChild(reference);
//
//        // Create DigestMethod element
//        Element digestMethod = doc.createElement("DigestMethod");
//        digestMethod.setAttribute("Algorithm", "http://www.w3.org/2000/09/xmldsig#sha1");
//        reference.appendChild(digestMethod);
//
//        // Create DigestValue element
//        Element digestValue = doc.createElement("DigestValue");
//        digestValue.appendChild(doc.createTextNode(Base64.getEncoder().encodeToString(digest)));
//        reference.appendChild(digestValue);
//
//        // Create SignatureValue element
//        Element signatureValue = doc.createElement("SignatureValue");
//        signatureValue.appendChild(doc.createTextNode(Base64.getEncoder().encodeToString(signature)));
//        signatureElement.appendChild(signatureValue);
//
//        // Transform document to string
//        TransformerFactory transformerFactory = TransformerFactory.newInstance();
//        Transformer transformer = transformerFactory.newTransformer();
//        DOMSource source = new DOMSource(doc);
//        StringWriter writer = new StringWriter();
//        StreamResult result = new StreamResult(writer);
//        transformer.transform(source, result);
//
//        return writer.toString();
//    }
//}

////i--------------id--------
//import org.bouncycastle.jce.provider.BouncyCastleProvider;
//import javax.xml.bind.DatatypeConverter;
//import javax.xml.parsers.DocumentBuilder;
//import javax.xml.parsers.DocumentBuilderFactory;
//import javax.xml.transform.Transformer;
//import javax.xml.transform.TransformerFactory;
//import javax.xml.transform.dom.DOMSource;
//import javax.xml.transform.stream.StreamResult;
//import java.io.StringWriter;
//import java.security.*;
//import java.util.Base64;
//import org.w3c.dom.Document;
//import org.w3c.dom.Element;
//
//public class App {
//
//    static {
//        Security.addProvider(new BouncyCastleProvider());
//    }
//
//    public static void main(String[] args) throws Exception {
//        // Sample ID
//        String id = "id-c1758946-f0e8-465b-b775-2dfc9ecf45ea";
//
//        // Compute SHA1 digest of the ID
//        byte[] digest = computeDigest(id);
//        System.out.println("Digest (Base64): " + Base64.getEncoder().encodeToString(digest));
//
//        // Generate RSA key pair
//        KeyPairGenerator keyPairGen = KeyPairGenerator.getInstance("RSA");
//        keyPairGen.initialize(2048);
//        KeyPair keyPair = keyPairGen.generateKeyPair();
//        PublicKey publicKey = keyPair.getPublic();
//        PrivateKey privateKey = keyPair.getPrivate();
//
//        // Sign the digest using RSA-SHA1
//        byte[] signature = signDigest(digest, privateKey);
//        System.out.println("Signature (Base64): " + Base64.getEncoder().encodeToString(signature));
//
//        // Create XML structure
//        String xml = createXMLStructure(digest, signature, id);
//        System.out.println("XML Structure: \n" + xml);
//    }
//
//    private static byte[] computeDigest(String data) throws Exception {
//        MessageDigest digest = MessageDigest.getInstance("SHA-1");
//        return digest.digest(data.getBytes("UTF-8"));
//    }
//
//    private static byte[] signDigest(byte[] digest, PrivateKey privateKey) throws Exception {
//        Signature signature = Signature.getInstance("SHA1withRSA");
//        signature.initSign(privateKey);
//        signature.update(digest);
//        return signature.sign();
//    }
//
//    private static String createXMLStructure(byte[] digest, byte[] signature, String id) throws Exception {
//        DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
//        DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
//        Document doc = docBuilder.newDocument();
//
//        // Create Signature element
//        Element signatureElement = doc.createElement("Signature");
//        doc.appendChild(signatureElement);
//
//        // Create SignatureMethod element
//        Element signatureMethod = doc.createElement("SignatureMethod");
//        signatureMethod.setAttribute("Algorithm", "http://www.w3.org/2000/09/xmldsig#rsa-sha1");
//        signatureElement.appendChild(signatureMethod);
//
//        // Create Reference element
//        Element reference = doc.createElement("Reference");
//        reference.setAttribute("URI", "#id");
//        signatureElement.appendChild(reference);
//
//        // Create DigestMethod element
//        Element digestMethod = doc.createElement("DigestMethod");
//        digestMethod.setAttribute("Algorithm", "http://www.w3.org/2000/09/xmldsig#sha1");
//        reference.appendChild(digestMethod);
//
//        // Create DigestValue element
//        Element digestValue = doc.createElement("DigestValue");
//        digestValue.appendChild(doc.createTextNode(Base64.getEncoder().encodeToString(digest)));
//        reference.appendChild(digestValue);
//
//        // Create SignatureValue element
//        Element signatureValue = doc.createElement("SignatureValue");
//        signatureValue.appendChild(doc.createTextNode(Base64.getEncoder().encodeToString(signature)));
//        signatureElement.appendChild(signatureValue);
//
//        // Transform document to string
//        TransformerFactory transformerFactory = TransformerFactory.newInstance();
//        Transformer transformer = transformerFactory.newTransformer();
//        DOMSource source = new DOMSource(doc);
//        StringWriter writer = new StringWriter();
//        StreamResult result = new StreamResult(writer);
//        transformer.transform(source, result);
//
//        return writer.toString();
//    }
//}
//

////generate id of type id-b52106e2-d4d5-424f-8a63-8862134f88f8
//import java.security.*;
//import java.util.Collections;
//
//import javax.xml.crypto.dsig.*;
//import javax.xml.crypto.dsig.dom.DOMSignContext;
//import javax.xml.crypto.dsig.keyinfo.*;
//import javax.xml.crypto.dsig.spec.*;
//import javax.xml.parsers.*;
//import javax.xml.transform.Transformer;
//import javax.xml.transform.TransformerFactory;
//import javax.xml.transform.dom.DOMSource;
//import javax.xml.transform.stream.StreamResult;
//
//import org.w3c.dom.*;
//
//public class App {
//
//    public static void main(String[] args) throws Exception {
//        // Step 1: Generate a random reference ID
//        String referenceID = generateReferenceID();
//        System.out.println("Reference ID: " + referenceID);
//
//        // Step 2: Create a SOAP message (for simplicity, let's consider a simple XML document)
//        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
//        DocumentBuilder db = dbf.newDocumentBuilder();
//        Document doc = db.newDocument();
//        Element rootElement = doc.createElement("SOAP-ENV:Envelope");
//        doc.appendChild(rootElement);
//        Element bodyElement = doc.createElement("SOAP-ENV:Body");
//        bodyElement.setTextContent("This is the content of the SOAP Body.");
//        rootElement.appendChild(bodyElement);
//
//        // Step 3: Create a digital signature
//        // Create a DOM XMLSignatureFactory
//        XMLSignatureFactory signatureFactory = XMLSignatureFactory.getInstance("DOM");
//
//        // Create a Reference to the enveloped document (in this case, we are signing the whole document)
//        Reference ref = signatureFactory.newReference("", signatureFactory.newDigestMethod(DigestMethod.SHA1, null));
//
//        // Create the SignedInfo
//        SignedInfo signedInfo = signatureFactory.newSignedInfo(signatureFactory.newCanonicalizationMethod(CanonicalizationMethod.INCLUSIVE,
//                (C14NMethodParameterSpec) null), signatureFactory.newSignatureMethod(SignatureMethod.RSA_SHA1, null), 
//                Collections.singletonList(ref));
//        KeyPairGenerator kpg = KeyPairGenerator.getInstance("RSA");
//        kpg.initialize(2048);
//        KeyPair kp = kpg.generateKeyPair();
//
//        KeyInfoFactory kif = signatureFactory.getKeyInfoFactory();
//        KeyValue kv = kif.newKeyValue(kp.getPublic());
//
//        KeyInfo ki = kif.newKeyInfo(Collections.singletonList(kv));
//
//        XMLSignature signature = signatureFactory.newXMLSignature(signedInfo, ki);
//        DOMSignContext dsc = new DOMSignContext(kp.getPrivate(), doc);
//        signature.sign(dsc);
//
//        // Step 4: Print the signed SOAP message
//        System.out.println("Signed SOAP message:\n" + convertDocumentToString(doc));
//    }
//
//    private static String generateReferenceID() {
//        return "id-" + java.util.UUID.randomUUID().toString();
//    }
//
//    private static String convertDocumentToString(Document doc) throws Exception {
//        DOMSource domSource = new DOMSource(doc);
//        StringWriter writer = new StringWriter();
//        StreamResult result = new StreamResult(writer);
//        TransformerFactory tf = TransformerFactory.newInstance();
//        Transformer transformer = tf.newTransformer();
//        transformer.transform(domSource, result);
//        return writer.toString();
//    }
//}
//


////--------SignatureValue-----------
//import java.io.FileInputStream;
//import java.security.KeyStore;
//import java.io.ByteArrayInputStream;
//import java.io.InputStream;
//import java.security.KeyFactory;
//import java.security.MessageDigest;
//import java.security.PrivateKey;
//import java.security.Signature;
//import java.security.cert.CertificateFactory;
//import java.security.cert.X509Certificate;
//import java.security.spec.PKCS8EncodedKeySpec;
//import java.util.Base64;
//
//public class App {
//    public static void main(String[] args) throws Exception {
//        // Your XML data
//        String xmlData = "<SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ds=\"http://www.w3.org/2000/09/xmldsig#\" xmlns:wsse=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd\" xmlns:wsu=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\">\n" +
//                "    <SOAP-ENV:Header>\n" +
//                "        <wsse:Security mustUnderstand=\"1\">\n" +
//                "            <wsse:UsernameToken>\n" +
//                "                <wsse:Username>B000200206</wsse:Username>\n" +
//                "            </wsse:UsernameToken>\n" +
//                "            <wsu:Timestamp>\n" +
//                "                <wsu:Created>30</wsu:Created>\n" +
//                "                <wsu:Expires>30</wsu:Expires>\n" +
//                "            </wsu:Timestamp>\n" +
//                "            <ds:Signature>\n" +
//                "                <ds:SignedInfo>\n" +
//                "                    <ds:CanonicalizationMethod Algorithm=\"http://www.w3.org/TR/2001/REC-xml-c14n-20010315\"/>\n" +
//                "                    <ds:SignatureMethod Algorithm=\"http://www.w3.org/2000/09/xmldsig#rsa-sha1\"/>\n" +
//                "                </ds:SignedInfo>\n" +
//                "            </ds:Signature>\n" +
//                "        </wsse:Security>\n" +
//                "    </SOAP-ENV:Header>\n" +
//                "    <SOAP-ENV:Body/>\n" +
//                "</SOAP-ENV:Envelope>";
//
//        // Load certificate
//        String certString = "-----BEGIN CERTIFICATE-----\n" +
//                "MIICtDCCAZygAwIBAgIGAY+VvpDSMA0GCSqGSIb3DQEBCwUAMBsxGTAXBgNVBAMM\n" +
//                "EFRlc3QgQ2VydGlmaWNhdGUwHhcNMjQwNTIwMTEyNDA1WhcNMjUwNTIwMTEyNDA1\n" +
//                "WjAbMRkwFwYDVQQDDBBUZXN0IENlcnRpZmljYXRlMIIBIjANBgkqhkiG9w0BAQEF\n" +
//                "AAOCAQ8AMIIBCgKCAQEA0xG1w6kUTmlN6sk9poEOjeBbfALT2mIfC/rsDy8a+M1T\n" +
//                "RfMv0DFay6ycDHPhcOIQn25Ub+MOkcGzpOD1V7X2/VDwaDlSiqfDBS/1pgz9m5Z2\n" +
//                "fFlLjPI0B73RkfYQrM99ejPQobJKsiwATQhcx0yFJKeimT6Nk9wYo+VG+d+/Sed9\n" +
//                "N4cMrD+S0/CvRaXx7lkdeCmLtWLIQwEKmagK/qk9A/n+fFypdXMLgXuU0cnz6PRb\n" +
//                "8GpByNX+EqZ3XBgJmHu4OJuGyEGYhOII8Q16BQZczR9CwV0gZHBjycPWAjcxFYau\n" +
//                "CsZK59SNtXK09q7p8wud3f4NJC+7I6SGTF6LNKEmHQIDAQABMA0GCSqGSIb3DQEB\n" +
//                "CwUAA4IBAQBnFU091UabnP/wu+8w/2pNpVWvgqhhohFQpBZKhz0yATxYNfz3U1kp\n" +
//                "nQto8+LvFnxsxLCE0VZKeZmuk3y7OD0SxksWW6Xq/YwRjcLdbPnk3IWLuf62lPTo\n" +
//                "O25rYWmKZBiNIgiCmVNQKs0s71ZC74umP3l7GX9F3QTwkiQxpUzhRmf/HV9fj1k2\n" +
//                "T/v0JtB56e7fiffLZ4yTE6pWEabQfBLHAsXKnBDIZtTGK04FKrkmKmQqhMiNOvTR\n" +
//                "5mOdeAShP7P3fMEwxQxsVeJHvGzgQ+7njBDjrWxNaVA7t6IEkiPezdKw6RKv65FR\n" +
//                "Nm/udaOWAi2+C3etvXEoQswBk4vRWeY/\n" +
//                "-----END CERTIFICATE-----";
//
//        // Convert certificate string to X509Certificate
//        CertificateFactory cf = CertificateFactory.getInstance("X.509");
//        InputStream certInputStream = new ByteArrayInputStream(certString.getBytes());
//        X509Certificate cert = (X509Certificate) cf.generateCertificate(certInputStream);
//
//        // Compute SHA-1 hash of canonicalized XML
//        MessageDigest digest = MessageDigest.getInstance("SHA-1");
//        byte[] xmlBytes = xmlData.getBytes("UTF-8");
//        byte[] hashBytes = digest.digest(xmlBytes);
//
//        // Sign the hash
////        PrivateKey privateKey = getPrivateKeyFromCert(cert);
//   
//      
//      KeyStore keystore = KeyStore.getInstance("JKS"); // Or "PKCS12" depending on the type of keystore
//      char[] keystorePassword = "keystorePassword".toCharArray();
//      String keystorePath = "src/main/resources/keystore.jks";
//      keystore.load(new FileInputStream(keystorePath), keystorePassword);
//
//      // Get the private key using the alias and password
//      String alias = "keyAlias";
//      char[] keyPassword = "keyPassword".toCharArray();
//      PrivateKey privateKey = (PrivateKey) keystore.getKey(alias, keyPassword);
//      
//      
//        Signature signature = Signature.getInstance("SHA1withRSA");
//        signature.initSign(privateKey);
//        signature.update(hashBytes);
//        byte[] signedBytes = signature.sign();
//
//        // Print the Base64 encoded signature
//        System.out.println("SHA-1 Signature: " + Base64.getEncoder().encodeToString(signedBytes));
//    }
////
////    private static PrivateKey getPrivateKeyFromCert(X509Certificate cert) throws Exception {
////        byte[] privateKeyBytes = cert.getPublicKey().getEncoded();
////        PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(privateKeyBytes);
////        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
////        return keyFactory.generatePrivate(keySpec);
////    }
//}



////-------encrypted data-------
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.cert.Certificate;
import java.util.Base64;
import java.util.Enumeration;
import java.util.Properties;
import java.security.SecureRandom;

public class App {
    public static void main(String[] args) throws Exception {
        // Path to your keystore and its password
        String keystorePath = "src/main/resources/keystore.jks";
        String keystorePassword = "keystorePassword";
        String keyAlias = "keyAlias";
        String keyPassword = "keyPassword";
        
        // Load the keystore
        KeyStore keystore = KeyStore.getInstance("JKS");
        try (FileInputStream keystoreInput = new FileInputStream(keystorePath)) {
            keystore.load(keystoreInput, keystorePassword.toCharArray());
        }

        // Retrieve the certificate and private key
        Certificate cert = keystore.getCertificate(keyAlias);
        PublicKey publicKey = cert.getPublicKey();
        PrivateKey privateKey = (PrivateKey) keystore.getKey(keyAlias, keyPassword.toCharArray());

        // Your XML data
//        String xmlData = "<SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ds=\"http://www.w3.org/2000/09/xmldsig#\" xmlns:wsse=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd\" xmlns:wsu=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\">\r\n"
//        		+ "	<SOAP-ENV:Header>\r\n"
//        		+ "	      <wsse:Security mustUnderstand=\"1\">\r\n"
//        		+ "		<wsse:UsernameToken>\r\n"
//        		+ "			<wsse:Username>B000200206</wsse:Username>\r\n"
//        		+ "		</wsse:UsernameToken>\r\n"
//        		+ "        	<wsu:Timestamp>\r\n"
//        		+ "        		<wsu:Created>30</wsu:Created>\r\n"
//        		+ "        		<wsu:Expires>30</wsu:Expires>\r\n"
//        		+ "		</wsu:Timestamp>\r\n"
//        		+ "        	<ds:Signature>\r\n"
//        		+ "          		<ds:SignedInfo>\r\n"
//        		+ "             			<ds:CanonicalizationMethod Algorithm=\"http://www.w3.org/TR/2001/REC-xml-c14n-20010315\"/>\r\n"
//        		+ "             				<ds:SignatureMethod Algorithm=\"http://www.w3.org/2000/09/xmldsig#rsa-sha1\"/>\r\n"
//        		+ "          		</ds:SignedInfo>\r\n"
//        		+ "        	</ds:Signature>\r\n"
//        		+ "  	     </wsse:Security>\r\n"
//        		+ "  	</SOAP-ENV:Header>\r\n"
//        		+ "  	<SOAP-ENV:Body/>\r\n"
//        		+ "</SOAP-ENV:Envelope>";
        String xmlData="<SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ds=\"http://www.w3.org/2000/09/xmldsig#\" xmlns:wsse=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd\" xmlns:wsu=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\"><SOAP-ENV:Header><wsse:Security mustUnderstand=\"1\"><wsse:UsernameToken><wsse:Username>B000200206</wsse:Username></wsse:UsernameToken><wsu:Timestamp><wsu:Created>30</wsu:Created><wsu:Expires>30</wsu:Expires></wsu:Timestamp><ds:Signature><ds:SignedInfo><ds:CanonicalizationMethod Algorithm=\"http://www.w3.org/TR/2001/REC-xml-c14n-20010315\"/><ds:SignatureMethod Algorithm=\"http://www.w3.org/2000/09/xmldsig#rsa-sha1\"/></ds:SignedInfo></ds:Signature></wsse:Security></SOAP-ENV:Header><SOAP-ENV:Body/></SOAP-ENV:Envelope>";

        // Generate AES key and IV
        KeyGenerator keyGen = KeyGenerator.getInstance("AES");
        keyGen.init(128);
        SecretKey aesKey = keyGen.generateKey();
        byte[] iv = new byte[16]; // AES block size is 16 bytes
        SecureRandom random = new SecureRandom();
        random.nextBytes(iv);
        IvParameterSpec ivSpec = new IvParameterSpec(iv);

        // Encrypt XML data using AES
        Cipher aesCipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        aesCipher.init(Cipher.ENCRYPT_MODE, aesKey, ivSpec);
        byte[] encryptedXmlBytes = aesCipher.doFinal(xmlData.getBytes("UTF-8"));

        // Encrypt AES key using RSA (public key from the certificate)
        Cipher rsaCipher = Cipher.getInstance("RSA/ECB/OAEPWithSHA-1AndMGF1Padding");
        rsaCipher.init(Cipher.WRAP_MODE, publicKey);
        byte[] encryptedAesKeyBytes = rsaCipher.wrap(aesKey);

        // Base64 encode the encrypted data
        String encryptedXml = Base64.getEncoder().encodeToString(encryptedXmlBytes);
        String encryptedAesKey = Base64.getEncoder().encodeToString(encryptedAesKeyBytes);
        String ivBase64 = Base64.getEncoder().encodeToString(iv);

        // Print the encrypted data
        System.out.println("Encrypted XML: " + encryptedXml);
        System.out.println("Encrypted AES Key: " + encryptedAesKey);
        System.out.println("IV: " + ivBase64);
    }
}





